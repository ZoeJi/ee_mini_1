#include <iostream>
#include <fstream>
#include "gate.h"
#include "gateList.h"
#include <list>
#include "gateType.h"
#include "gateType.cpp"
#include "gateList.cpp"

using namespace std;

/*
 * getIOname is used to extract the name of primary input or output
 */
void write_result(int inputCount, int outputCount, string fileName, gateList* myGateList);
string getIOname(string str);
string getGateType(string str);


int main(int argc, char *argv[]) {

    string aline;
    string gateName;
    string thisGateType;
    gateType* newGateType;
    gate* newGate;
    gateList myGateList;
    int inputCount = 0, outputCount = 0;
    ifstream fileInput ( argv[2] );

    if ( argc != 3 ) // argc should be 3 for correct execution
        cout<<"usage: "<< argv[0] <<" <read command> <filename>\n <read command> options: read_ckt, read_nldm\n";
    else {
        if(strncmp(argv[1],"read_ckt", 9) == 0){
            if ( !fileInput.is_open() )
                cout<<"Could not open file\n";
            else {
                while(!fileInput.eof()) {
                    getline(fileInput,aline);
                    if(isalpha(aline[0]) || (aline[0]>='0' && aline[0]<= '9')) {
                        if(!aline.empty()) {
                            if(aline[0]!='#') {
                                if(aline.substr(0,5)=="INPUT") {
                                    inputCount++;
                                    gateName = getIOname(aline);
                                }
                                else if(aline.substr(0,6)=="OUTPUT") {
                                    outputCount++;
                                }
                                else {
                                    thisGateType = getGateType(aline);
                                    newGateType = myGateList.searchGateType(thisGateType);
                                    if(newGateType == NULL) {
                                        myGateList.getTypeList()->push_back(new gateType(thisGateType));
                                        newGateType = myGateList.searchGateType(thisGateType);
                                        newGateType->typeCountIncr();
                                    }
                                    else {
                                        newGateType->typeCountIncr();
                                    }
                                }
                            }
                        }
                    }
                }

//                char x;
//                // the_file.get ( x ) returns false if the end of the file
//                //  is reached or an error occurs
//                while ( fileInput.get ( x ) )
//                    cout<< x;
            }
        }
        else if(strncmp(argv[1],"read_nldm", 9) == 0){
        }

        write_result(inputCount, outputCount, argv[2], &myGateList);
    }
}

void write_result(int inputCount, int outputCount, string fileName, gateList* myGateList){
    string resultFile = fileName + ".out";
    ofstream result;
    list<gateType*>::iterator k;
    result.open(resultFile.c_str());

    result << "------------------------------------------------" << endl;
    result << inputCount << " primary inputs" << endl;
    result << outputCount << " primary outputs"<< endl;
    for( k=myGateList->getTypeList()->begin();k!=myGateList->getTypeList()->end();k++)
    {
        result<<(*k)->getTypeCount() << ' ' << (*k)->getTypeName()<< ' ' << "gates"<< endl;
    }
    result << "------------------------------------------------" << endl;
    result.close();
    cout << "Result is output to the file: " << resultFile << endl;
}

string getIOname(string str) {
    int head,tail;
    head=str.find('(')+1;
    tail=str.find(')');
    tail=tail-head;
    str =str.substr(head,tail);
    /*discard spaces at the head of the string*/
    while(*(str.begin())==' ')
    {
        str.erase(str.begin());
    }
    /*discards spaces at the tail of the string*/
    while(*(str.rbegin())==' ')
    {
        str=str.substr(0,str.size()-1);
    }
    return str;
}

string getGateType(string str)
{
    int head,tail;
    head=str.find('=')+1;
    tail=str.find('(');
    tail=tail-head;
    str =str.substr(head,tail);
    /*discards spaces at the head of the string*/
    while(*(str.begin())==' ')
    {
        str.erase(str.begin());
    }
    /*discards spaces at the tail of the string*/
    while(*(str.rbegin())==' ')
    {
        str=str.substr(0,str.size()-1);
    }
    return str;
}