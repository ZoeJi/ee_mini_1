//
// Created by Qianying Ji on 10/10/16.
//

#include <list>
#include "gateList.h"

gateType* gateList::searchGateType(string name){
    list<gateType*>::iterator i;
    for(i=typeList.begin();i!=typeList.end();i++)
    {
        if (name==((*i)->getTypeName()))
            return *i;
    }
    return NULL;
};

list<gateType*>* gateList::getTypeList(){
    return &typeList;
};