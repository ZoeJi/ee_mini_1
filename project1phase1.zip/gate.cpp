//
// Created by Qianying Ji on 10/10/16.
//

#include "gate.h"
#include <string>
using namespace std;
